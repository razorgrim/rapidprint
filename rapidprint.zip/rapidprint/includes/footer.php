<footer>
    <p>&copy; <?php echo date("Y"); ?> RapidPrint. All rights reserved.</p>
</footer>

<style>
    footer {
        text-align: center;
        padding: 10px 20px;
        color: #fff; /* White text */
        font-family: 'Georgia', serif; /* Stylish serif font */
        font-size: 16px;
        letter-spacing: 1px;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7); /* Text shadow for a 3D effect */
    }
</style>
